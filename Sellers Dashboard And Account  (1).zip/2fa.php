<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Two-Factor Authentication</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="header">
    <h1>Two-Factor Authentication</h1>
</div>

<div class="container">
    <div class="card">
        <form method="POST" action="">
            <label for="phone">Enter your phone number:</label>
            <input type="tel" id="phone" name="phone" required>

            <button type="submit">Enable 2FA</button>
        </form>
    </div>
</div>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>