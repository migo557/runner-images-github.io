<?php
session_start();
require 'db.php';

// Admin authentication would be here

$payouts_query = $conn->prepare("SELECT * FROM payout_requests WHERE status = 'pending'");
$payouts_query->execute();
$payouts = $payouts_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payout Requests</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="admin-payouts-container">
    <h1>Payout Requests</h1>
    
    <table>
        <thead>
            <tr>
                <th>Seller ID</th>
                <th>Requested Amount</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($payout = $payouts->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($payout['seller_id']); ?></td>
                    <td><?php echo number_format($payout['amount'], 2); ?></td>
                    <td><?php echo htmlspecialchars($payout['status']); ?></td>
                    <td>
                        <form method="POST" action="process_payout.php">
                            <input type="hidden" name="payout_id" value="<?php echo $payout['id']; ?>">
                            <button type="submit" name="action" value="approve">Approve</button>
                            <button type="submit" name="action" value="deny">Deny</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>