<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Analytics</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="header">
    <h1>Your Sales Analytics</h1>
</div>

<div class="container">
    <div class="card">
        <h2>Sales Overview</h2>
        <p>Total Sales: $<?php echo number_format($total_sales, 2); ?></p>
        <p>Average Order Value: $<?php echo number_format($average_order_value, 2); ?></p>
    </div>

    <div class="card">
        <h2>Sales Trends</h2>
        <!-- Graph or chart implementation can go here -->
    </div>
</div>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>