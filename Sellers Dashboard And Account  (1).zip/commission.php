<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Commissions</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="header">
    <h1>Your Commissions</h1>
</div>

<div class="container">
    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>Commission ID</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($commission = $commissions->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($commission['id']); ?></td>
                        <td><?php echo number_format($commission['amount'], 2); ?></td>
                        <td><?php echo htmlspecialchars($commission['status']); ?></td>
                        <td><?php echo htmlspecialchars($commission['date']); ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>