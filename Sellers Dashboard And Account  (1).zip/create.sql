CREATE TABLE commissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    seller_id INT NOT NULL,
    product_name VARCHAR(255),
    sale_amount DECIMAL(10, 2),
    commission_amount DECIMAL(10, 2),
    date DATETIME DEFAULT CURRENT_TIMESTAMP,
    status ENUM('pending', 'approved') DEFAULT 'pending',
    FOREIGN KEY (seller_id) REFERENCES sellers(id)
);

CREATE TABLE payout_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    seller_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'approved', 'denied') DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (seller_id) REFERENCES sellers(id)
);

CREATE TABLE payment_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    seller_id INT NOT NULL,
    method VARCHAR(255),
    FOREIGN KEY (seller_id) REFERENCES sellers(id)
);