<?php
session_start();
if (!isset($_SESSION['seller_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

$seller_id = $_SESSION['seller_id'];

// Fetch seller data
$seller_query = $conn->prepare("SELECT * FROM sellers WHERE id = ?");
$seller_query->bind_param("i", $seller_id);
$seller_query->execute();
$seller = $seller_query->get_result()->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Seller Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="header">
    <h1>Welcome, <?php echo htmlspecialchars($seller['name']); ?>!</h1>
</div>

<div class="container">
    <nav class="nav">
        <a href="products.php">Manage Products</a>
        <a href="orders.php">View Orders</a>
        <a href="commissions.php">Commission Tracking</a>
        <a href="withdraw.php">Request Withdrawal</a>
        <a href="help.php">Help Center</a>
    </nav>

    <div class="card">
        <h2>Your Account Overview</h2>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($seller['email']); ?></p>
        <p><strong>Business Type:</strong> <?php echo htmlspecialchars($seller['business_type']); ?></p>
        <p><strong>Total Sales:</strong> $<?php echo number_format($seller['total_sales'], 2); ?></p>
    </div>

    <div class="card">
        <h2>Latest Commissions</h2>
        <!-- Fetch and display latest commissions here -->
    </div>
</div>

</body>
</html>