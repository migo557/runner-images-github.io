<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Feedback</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="header">
    <h1>We Value Your Feedback</h1>
</div>

<div class="container">
    <div class="card">
        <form method="POST" action="">
            <label for="rating">Rate Your Experience:</label>
            <select id="rating" name="rating" required>
                <option value="5">5 - Excellent</option>
                <option value="4">4 - Good</option>
                <option value="3">3 - Average</option>
                <option value="2">2 - Below Average</option>
                <option value="1">1 - Poor</option>
            </select>

            <label for="comments">Additional Comments:</label>
            <textarea id="comments" name="comments" rows="4"></textarea>

            <button type="submit">Submit Feedback</button>
        </form>
    </div>
</div>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>!