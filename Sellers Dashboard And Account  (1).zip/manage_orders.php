<?php
session_start();
if (!isset($_SESSION['seller_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

$seller_id = $_SESSION['seller_id'];
$order_query = $conn->prepare("SELECT * FROM orders WHERE seller_id = ? ORDER BY date DESC");
$order_query->bind_param("i", $seller_id);
$order_query->execute();
$orders = $order_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Orders</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="order-container">
    <h1>Your Orders</h1>
    
    <ul>
        <?php while ($order = $orders->fetch_assoc()): ?>
            <li>
                Order ID: <?php echo htmlspecialchars($order['id']); ?> - Total: $<?php echo htmlspecialchars($order['total']); ?> - Status: <?php echo htmlspecialchars($order['status']); ?> - Date: <?php echo htmlspecialchars($order['date']); ?>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>