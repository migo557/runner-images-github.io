<?php
session_start();
if (!isset($_SESSION['seller_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

$seller_id = $_SESSION['seller_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_product'])) {
        $product_name = $_POST['product_name'];
        $price = $_POST['price'];
        $description = $_POST['description'];

        $stmt = $conn->prepare("INSERT INTO products (seller_id, name, price, description) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isds", $seller_id, $product_name, $price, $description);
        $stmt->execute();
    }
}

$product_query = $conn->prepare("SELECT * FROM products WHERE seller_id = ?");
$product_query->bind_param("i", $seller_id);
$product_query->execute();
$products = $product_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Products</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="product-container">
    <h1>Manage Your Products</h1>

    <form method="POST" action="">
        <h2>Add New Product</h2>
        <label for="product_name">Product Name:</label>
        <input type="text" id="product_name" name="product_name" required>

        <label for="price">Price:</label>
        <input type="number" step="0.01" id="price" name="price" required>

        <label for="description">Description:</label>
        <textarea id="description" name="description" required></textarea>

        <button type="submit" name="add_product">Add Product</button>
    </form>

    <h2>Your Products</h2>
    <ul>
        <?php while ($product = $products->fetch_assoc()): ?>
            <li>
                <?php echo htmlspecialchars($product['name']) . ' - $' . htmlspecialchars($product['price']); ?>
                <form method="POST" action="delete_product.php" style="display:inline;">
                    <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                    <button type="submit">Delete</button>
                </form>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>