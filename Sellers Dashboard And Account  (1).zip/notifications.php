<?php
session_start();
if (!isset($_SESSION['seller_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

$seller_id = $_SESSION['seller_id'];
$notification_query = $conn->prepare("SELECT * FROM notifications WHERE seller_id = ? ORDER BY date DESC");
$notification_query->bind_param("i", $seller_id);
$notification_query->execute();
$notifications = $notification_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Notifications</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="notification-container">
    <h1>Your Notifications</h1>
    
    <ul>
        <?php while ($notification = $notifications->fetch_assoc()): ?>
            <li>
                <?php echo htmlspecialchars($notification['message']); ?> - Date: <?php echo htmlspecialchars($notification['date']); ?>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>