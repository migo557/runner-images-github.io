<?php
session_start();
if (!isset($_SESSION['seller_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

$seller_id = $_SESSION['seller_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Add payment method
    $method = $_POST['payment_method'];

    $stmt = $conn->prepare("INSERT INTO payment_methods (seller_id, method) VALUES (?, ?)");
    $stmt->bind_param("is", $seller_id, $method);
    $stmt->execute();
}

$payment_query = $conn->prepare("SELECT * FROM payment_methods WHERE seller_id = ?");
$payment_query->bind_param("i", $seller_id);
$payment_query->execute();
$methods = $payment_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment Methods</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="payment-container">
    <h1>Your Payment Methods</h1>

    <form method="POST" action="">
        <label for="payment_method">Add Payment Method:</label>
        <input type="text" id="payment_method" name="payment_method" required>
        <button type="submit">Add</button>
    </form>

    <h2>Current Methods</h2>
    <ul>
        <?php while ($method = $methods->fetch_assoc()): ?>
            <li><?php echo htmlspecialchars($method['method']); ?></li>
        <?php endwhile; ?>
    </ul>
</div>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>