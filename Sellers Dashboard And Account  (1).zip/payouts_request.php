<?php
session_start();
if (!isset($_SESSION['seller_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

$seller_id = $_SESSION['seller_id'];

// Check total earnings
$earnings_query = $conn->prepare("SELECT SUM(commission_amount) AS total_earnings FROM commissions WHERE seller_id = ? AND status = 'approved'");
$earnings_query->bind_param("i", $seller_id);
$earnings_query->execute();
$earnings_result = $earnings_query->get_result()->fetch_assoc();
$total_earnings = $earnings_result['total_earnings'] ?? 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Process payout request
    $amount_requested = $_POST['amount'];

    if ($amount_requested <= $total_earnings) {
        $stmt = $conn->prepare("INSERT INTO payout_requests (seller_id, amount, status) VALUES (?, ?, 'pending')");
        $stmt->bind_param("id", $seller_id, $amount_requested);
        if ($stmt->execute()) {
            $success_message = "Payout request submitted successfully!";
        }
    } else {
        $error_message = "Requested amount exceeds total earnings.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payout Request</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="payout-request-container">
    <h1>Payout Request</h1>
    <p>Your total earnings: $<?php echo number_format($total_earnings, 2); ?></p>
    
    <?php if (isset($error_message)): ?>
        <p style="color:red;"><?php echo $error_message; ?></p>
    <?php elseif (isset($success_message)): ?>
        <p style="color:green;"><?php echo $success_message; ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="amount">Amount to withdraw:</label>
        <input type="number" id="amount" name="amount" step="0.01" required>
        <button type="submit">Request Payout</button>
    </form>
</div>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>