<?php
session_start();
if (!isset($_SESSION['seller_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

$seller_id = $_SESSION['seller_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Add or update product
    $product_name = $_POST['product_name'];
    $price = $_POST['price'];
    $description = $_POST['description'];
    $action = $_POST['action'];
    $product_id = $_POST['product_id'] ?? null;

    if ($action == 'add') {
        $stmt = $conn->prepare("INSERT INTO products (seller_id, product_name, price, description) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("isds", $seller_id, $product_name, $price, $description);
        $stmt->execute();
        $success_message = "Product added successfully!";
    } elseif ($action == 'update' && $product_id) {
        $stmt = $conn->prepare("UPDATE products SET product_name = ?, price = ?, description = ? WHERE id = ?");
        $stmt->bind_param("sdsi", $product_name, $price, $description, $product_id);
        $stmt->execute();
        $success_message = "Product updated successfully!";
    }
}

// Fetch products for the seller
$product_query = $conn->prepare("SELECT * FROM products WHERE seller_id = ?");
$product_query->bind_param("i", $seller_id);
$product_query->execute();
$products = $product_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Products</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="products-container">
    <h1>Your Products</h1>

    <?php if (isset($success_message)): ?>
        <p style="color:green;"><?php echo $success_message; ?></p>
    <?php endif; ?>

    <form method="POST" action="">
        <h2>Add or Update Product</h2>
        <input type="hidden" name="product_id" value="">
        <label for="product_name">Product Name:</label>
        <input type="text" id="product_name" name="product_name" required>

        <label for="price">Price:</label>
        <input type="number" id="price" name="price" step="0.01" required>

        <label for="description">Description:</label>
        <textarea id="description" name="description" required></textarea>

        <select name="action">
            <option value="add">Add Product</option>
            <option value="update">Update Product</option>
        </select>

        <button type="submit">Submit</button>
    </form>

    <h2>Your Existing Products</h2>
    <table>
        <thead>
            <tr>
                <th>Product Name</th>
                <th>Price</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($product = $products->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($product['product_name']); ?></td>
                    <td><?php echo number_format($product['price'], 2); ?></td>
                    <td><?php echo htmlspecialchars($product['description']); ?></td>
                    <td>
                        <form method="POST" action="">
                            <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                            <button type="submit" name="action" value="update">Edit</button>
                            <button type="submit" name="action" value="delete">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>