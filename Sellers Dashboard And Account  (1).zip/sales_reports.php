<?php
session_start();
if (!isset($_SESSION['seller_id'])) {
    header('Location: login.php');
    exit();
}

require 'db.php';

$seller_id = $_SESSION['seller_id'];
$sales_query = $conn->prepare("SELECT * FROM sales WHERE seller_id = ? ORDER BY date DESC");
$sales_query->bind_param("i", $seller_id);
$sales_query->execute();
$sales = $sales_query->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sales Reports</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<div class="sales-container">
    <h1>Your Sales Reports</h1>
    
    <ul>
        <?php while ($sale = $sales->fetch_assoc()): ?>
            <li>
                Sale ID: <?php echo htmlspecialchars($sale['id']); ?> - Amount: $<?php echo htmlspecialchars($sale['amount']); ?> - Date: <?php echo htmlspecialchars($sale['date']); ?>
            </li>
        <?php endwhile; ?>
    </ul>
</div>

<a href="dashboard.php">Back to Dashboard</a>

</body>
</html>